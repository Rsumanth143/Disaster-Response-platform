// server.js
const express = require('express');
const cors = require('cors');
const http = require('http');
const { Server } = require('socket.io');
const bodyParser = require('body-parser');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: '*'
  }
});

app.use(cors());
app.use(bodyParser.json());

// Mock databases
let disasters = [];
let resources = [];
let reports = [];

// WebSocket listeners
io.on('connection', (socket) => {
  console.log('Client connected');
});

// REST APIs
app.post('/disasters', (req, res) => {
  const disaster = { id: Date.now().toString(), ...req.body };
  disasters.push(disaster);
  io.emit('disaster_updated', disaster);
  res.status(201).json(disaster);
});

app.get('/disasters', (req, res) => {
  const { tag } = req.query;
  if (tag) {
    const filtered = disasters.filter(d => d.tags.includes(tag));
    res.json(filtered);
  } else {
    res.json(disasters);
  }
});

app.put('/disasters/:id', (req, res) => {
  const index = disasters.findIndex(d => d.id === req.params.id);
  if (index !== -1) {
    disasters[index] = { ...disasters[index], ...req.body };
    io.emit('disaster_updated', disasters[index]);
    res.json(disasters[index]);
  } else {
    res.status(404).json({ error: 'Not found' });
  }
});

app.delete('/disasters/:id', (req, res) => {
  disasters = disasters.filter(d => d.id !== req.params.id);
  io.emit('disaster_updated', { id: req.params.id, deleted: true });
  res.status(204).end();
});

// Mock social media
app.get('/disasters/:id/social-media', (req, res) => {
  const sample = [
    { post: '#floodrelief Need food in NYC', user: 'citizen1' },
    { post: 'Rescue team arrived at Manhattan', user: 'volunteer2' }
  ];
  io.emit('social_media_updated', sample);
  res.json(sample);
});

// Mock geocode endpoint
app.post('/geocode', (req, res) => {
  const { location_name } = req.body;
  const mockLatLng = { lat: 40.7128, lng: -74.0060 }; // Manhattan
  res.json({ location_name, coordinates: mockLatLng });
});

// Start server
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
